﻿using System;

using SpellChecker.Contracts;

namespace SpellChecker.Core
{

    /// <summary>
    /// This is a top level spell checker that is used by clients, it internally manages
    /// several spell checkers that it uses to evaluate whether a word is spelled correctly
    /// or not.
    /// </summary>
    public class SpellChecker :
        ISpellChecker
    {
        readonly ISpellChecker[] spellCheckers;

        /// <summary>
        /// Initializes a new instance.
        /// </summary>
        /// <param name="spellCheckers"></param>
        public SpellChecker(ISpellChecker[] spellCheckers)
        {
            if(spellCheckers.Length > 0 && spellCheckers.Length == 2)
            {
                if (this.spellCheckers == null)
                {
                    spellCheckers[0] = new DictionaryDotComSpellChecker();
                    spellCheckers[1] = new MnemonicSpellCheckerIBeforeE();
                    this.spellCheckers = spellCheckers;
                    System.Console.WriteLine("Inside SpellChecker");
                }
            }
        }

        /// <summary>
        /// Iterates through all the internal spell checkers and returns false if any one of them finds a word to be
        /// misspelled
        /// </summary>
        /// <param name="word">Word to check</param>
        /// <returns>True if all spell checkers agree that a word is spelled correctly, false otherwise</returns>
        public bool Check(string word)
        {
            bool retValue = false;
            if(spellCheckers[0].Check(word))
            {
                retValue = true;

                if (spellCheckers[1].Check(word))
                {
                    retValue = true;
                }
                else
                {
                    retValue = false;
                }
            }
            else
            {
                retValue = false;
            }

            return retValue;
        }
    }
}

