﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using SpellChecker.Contracts;
using System.Net;
using System.IO;

namespace SpellChecker.Core
{

    /// <summary>
    /// This is a dictionary based spell checker that uses dictionary.com to determine if
    /// a word is spelled correctly.
    /// 
    /// The URL to do this looks like this: http://dictionary.reference.com/browse/<word>
    /// where <word> is the word to be checked.
    /// 
    /// We look for something in the response that gives us a clear indication whether the
    /// word is spelled correctly or not.
    /// </summary>
    public class DictionaryDotComSpellChecker :
        ISpellChecker
    {
        private WebRequest request;
        private Stream dataStream;
        private string status;
        public bool Check(string word)
        {
            bool retVal = false;

            try
            {
                var url = "http://dictionary.reference.com/browse/" + word;

                System.Console.WriteLine("Url is " + url);

                request = WebRequest.Create(url);

                // Get the original response.
                WebResponse response = request.GetResponse();

                var webResponse = (HttpWebResponse)response;
                if (webResponse.StatusCode == HttpStatusCode.OK)
                {
                    retVal = true;
                }
                else
                {
                    retVal = false;
                }

            }
            catch(WebException wex)
            {
                string exception = wex.ToString();
            }

            return retVal;
        }
    }
}

